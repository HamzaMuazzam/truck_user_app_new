package com.lahdatech.trucking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
